$(function(){
	$("#header").load("../templates/header.html")
	$("#footer").load("../templates/footer.html")	
});